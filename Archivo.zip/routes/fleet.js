var sql = require("mssql");

var config = {
    "server": "104.238.110.124\\empresascasanova",
    "user": "sa",
    "password": "Pl8493914",
    "database": "compresu_vipadmin",
   "connectionTimeout": 300000,
    "idleTimeoutMillis": 300000,
   "requestTimeout": 300000,
   "stream":true,
};


//var config = {
    //"server": "HPDESARROLLO\\HPDESARROLLO2019",
   // "user": "sa",
    //"password": "Pl8493914",
   // "database": "compresu_vipadmin",
   // "connectionTimeout": 300000,
    //"idleTimeoutMillis": 300000,
   // "requestTimeout": 300000,
  //  "stream":true
//};

exports.all = function(req, res) {
    sql.close();
    sql.connect(config, function(err) {
        if (err) console.log(err);
        var request = new sql.Request();
        request.query('select * from dba_vendedor ', function(err, recordset) {
            if (err) console.log(err)
      
            res.send(columns);

        });

    });

    alert()

};

//Endpoint : Consulta de Datos del operador Para Pago en Plataforma Punto Pago
//Envia Numero de Cedula
exports.id = function(req, res) {
    let id = (req.params.id);
    console.log(id);
    sql.close();
    sql.connect(config, function(err) {
        if (err) console.log(err);
        var request = new sql.Request();
        request.query('cosnulta_operador_api ' + "'" + id + "'", function(err, result) {
            
            if (err) console.log("Error")
            res.send(result.recordset);


        });

    });

};

//Endpoint: Consulta de Top diez Peores Pagadores
//Se le envia el nombre del cobrador 
exports.dos = function(req, res) {
    var user = (req.params.us);
    console.log(user);
    sql.close();
    sql.connect(config, function(err) {
        if (err) console.log(err);
        var request = new sql.Request();
        request.query('json_toppeores_pagadores' + "'" + user + "'", function(err, result) {
            if (err) console.log(err)
            console.log(result);
            res.send(result.recordset);

        });

    });



};

//Endpoint: Consulta Expectativa ppr Cobrador 
//Se le envia el nombre del cobrador 
exports.tres = function(req, res) {
    var user = (req.params.us);
    console.log(user);
    sql.close();
    sql.connect(config, function(err) {
        if (err) console.log(err);
        var request = new sql.Request();
        request.query('jsonexpectativapty' + "'" + user + "'", function(err, result) {
            if (err) console.log(err)
            console.log(result);
            res.send(result.recordset);

        });

    });



};


//Endpoint: Consulta Expectativa ppr Cobrador 
//Se le envia el nombre del cobrador 
exports.cuatro = function(req, res) {
    var user = (req.params.us);
    console.log(user); 
    sql.close();
    sql.connect(config, function(err) {
        if (err) console.log(err);
        var request = new sql.Request();
        request.query('jsonexpectativaptyheader' + "'" + user + "'", function(err, result) {
            if (err) console.log(err)
            console.log(result);
            res.send(result.recordset);

        });

    });



};

//Endpoint: Consulta Resumen Parados 
//Se le envia la inicial de la Unidad de negocio (C.P.V)
exports.cinco = function(req, res) {
    var ug = (req.params.us);
    console.log(ug); 
    sql.close();
    sql.connect(config, function(err) {
        if (err) console.log(err);
        var request = new sql.Request();
        request.query('dbo_ver_paraadosxcierre_gapp' + "'" +ug + "'", function(err, result) {
            if (err) console.log(err)
            console.log(result);
            res.send(result.recordset);

        });

    });



};

//Endpoint: Consulta Lista negra de Operadores  
//Se le envia el nombre del cobrador 
exports.diez = function(req, res) {
    var user = (req.params.us);
    console.log(user); 
    sql.close();
    sql.connect(config, function(err) {
        if (err) console.log(err);
        var request = new sql.Request();
        request.query('pxsecret ' + user , function(err, result) {
            if (err) console.log(err)
            console.log(result);
            res.send(result.recordset);

        });

    });



};